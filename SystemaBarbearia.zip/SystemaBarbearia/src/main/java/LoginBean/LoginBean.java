package LoginBean;

public class LoginBean {

}
